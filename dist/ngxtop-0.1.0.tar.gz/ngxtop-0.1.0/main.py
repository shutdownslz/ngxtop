def main():
    print("Hello from ngxtop!")


if __name__ == "__main__":
    main()
